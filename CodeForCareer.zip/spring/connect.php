<?php
$HOSTNAME="localhost";
$USERNAME="root";
$PASSWORD="12345";
$DATABASE="spring";
// $PORT = "3306";


$con = mysqli_connect($HOSTNAME,$USERNAME,$PASSWORD,$DATABASE);
// $con = new mysqli($HOSTNAME,$USERNAME,$PASSWORD,$DATABASE);
 
if(!$con){
    die(mysqli_connect_error());
}

echo ("Connected Successfully");
?>